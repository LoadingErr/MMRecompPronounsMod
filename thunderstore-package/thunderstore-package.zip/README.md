# Majora's Mask Recompiled: Female/Neutral Language Mod

This is a mod for Majora's Mask: Recompiled that allows you to replace all instances of gendered language referring to Link with appropriate female or gender-neutral counterparts.

MAKE SURE YOU SET THE OPTION BEFORE YOU LAUNCH THE GAME!
