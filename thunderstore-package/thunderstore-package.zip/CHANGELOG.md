# 1.0.2

Added changes for a significant amount of additional text.

# 1.0.1

Updated mod page to link to the correct repository.

# 1.0.0

Initial release.